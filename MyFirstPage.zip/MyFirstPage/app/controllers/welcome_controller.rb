class WelcomeController < ApplicationController

def index
end

def mypage
end

def test_page2
end

end
